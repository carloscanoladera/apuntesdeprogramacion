package interfazfuncion;

public class EjemploInterfazFuncion {

}
