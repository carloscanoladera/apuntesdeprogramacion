package fundamentosprogramacionfuncional;

public class FunctionalInterfaceExample {

}
