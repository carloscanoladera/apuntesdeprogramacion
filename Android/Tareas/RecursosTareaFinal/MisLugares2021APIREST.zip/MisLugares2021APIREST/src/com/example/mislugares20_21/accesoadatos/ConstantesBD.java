package com.example.mislugares20_21.accesoadatos;

import java.io.Serializable;

public class ConstantesBD implements Serializable {


	public static final int MYSQL = 1;
	public static final int MYSQL_ClOUD = 2;


}
