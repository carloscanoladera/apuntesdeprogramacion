/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controladores;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import memento.CareTaker;
import memento.MementoData;
import modelo.GeneraUsuarios;
import modelo.Usuario;
import mvc.vistas.VentanaPrincipal;

/**
 *
 * @author carlo
 */
public class ControladorPrincipal {
    
    private static MementoData snapShot;
    private static VentanaPrincipal ventana ;
    
         public static void inicializarControladorPrincipal() {
        
       
          cargarDatos();
          ventana = new VentanaPrincipal();
          ventana.setVisible(true);
           
           
        
    }
         
         
    public static boolean sePuedeRedo () {
        
        return !CareTaker.getEsUltimoSnapshot();
        
    }
    
     public static boolean sePuedeUndo () {
        
        return !CareTaker.getEsPrimeroSnapshot();
        
    }
     
     
     public static void redo() {
         
         
         snapShot = CareTaker.forward();
         ventana.refreshVentana();
          ControladorPrincipal.notificarCambioDatos();
         
       
        
         
         
     }
     
     
     public static void undo() {
         
         
         snapShot = CareTaker.back();
         ventana.refreshVentana();
          ControladorPrincipal.notificarCambioDatos();
         
        
         
         
     }
         
    public static List<Usuario> getListaUsuarios() {
        
        return snapShot.getListaUsuarios();
    }
    
    
   
     
     
     public static void nuevoUsuario() {
         
          ControladorUsuario.inicializarControladorUsuario(Optional.empty());
         
     }
     
     public static void nuevoSnapShot() {
         
              snapShot = CareTaker.addSnapShot();
            
         
     }
     
     public static void modificarUsuario(String nombreCompleto) {
         
       
        
         ControladorUsuario.inicializarControladorUsuario(snapShot.getListaUsuarios().stream()
                 .filter(usuario-> (usuario.getNombre() + " " +usuario.getApellidos()).equals(nombreCompleto)).findAny());
          ControladorPrincipal.notificarCambioDatos();
         
     }
     
     public static void borrarUsuario(String nombreCompleto) {
         
        nuevoSnapShot();
     
         
         snapShot.getListaUsuarios().remove(snapShot.getListaUsuarios().stream()
                 .filter(usuario-> (usuario.getNombre() + " " +usuario.getApellidos()).equals(nombreCompleto)).findAny().get());
         ControladorPrincipal.notificarCambioDatos();
         
     }
     
       public static int getIdNuevo() {
           
           if (snapShot.getListaUsuarios().size()==0)
               return 1;
           else
                return 
                        snapShot
                         .getListaUsuarios()
                         .stream()
                         .collect(Collectors.maxBy((u1,u2)->u1.getId()>u2.getId()?1:(u1.getId()==u2.getId()?0:-1))).get().getId()+1;
       }
    
     
       private static void cargarDatos() {
           
           
           
         
          snapShot = new MementoData( GeneraUsuarios.devueveUsuariosLista(100));
          CareTaker.inicializaCareTaker(snapShot);
         
         
     }
       
       
       
       public static void notificarCambioDatos() {
           
           
           ventana.refreshVentana();
       }
     
}
