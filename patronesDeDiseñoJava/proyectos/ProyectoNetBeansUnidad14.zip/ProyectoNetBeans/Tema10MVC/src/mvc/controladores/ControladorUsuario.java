/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.controladores;

import java.util.List;
import java.util.Optional;
import modelo.Usuario;
import mvc.vistas.VentanaPrincipal;
import mvc.vistas.VentanaUsuario;

/**
 *
 * @author carlo
 */
public class ControladorUsuario {
    
    
     private static Optional<Usuario> usuario;
    private static VentanaUsuario ventana ;
    
         public static void inicializarControladorUsuario(Optional<Usuario> user) {
        
       
          usuario=user;
          ventana = new VentanaUsuario();
          ventana.setVisible(true);
           
           
        
    }
         
         
         public static Optional<Usuario> getDatosUsuario() {
             
             return usuario;
         }
         
         
         public static void guardarUsuario(String nombre, String apellidos, int edad , int conexiones) {
             ControladorPrincipal.nuevoSnapShot();
             
             
             if (usuario.isEmpty()) {
                 
                 
                 usuario= Optional.of(new Usuario(ControladorPrincipal.getIdNuevo(),nombre,apellidos,edad,0.0, conexiones));
                 
                 ControladorPrincipal.getListaUsuarios().add(usuario.get());
                 
             } else {
            
            usuario = ControladorPrincipal.getListaUsuarios().stream().filter(u->u.getId()==usuario.get().getId()).findAny();
            usuario.get().setNombre(nombre);
            usuario.get().setApellidos(apellidos);
            
            usuario.get().setEdad(edad);
            usuario.get().setNumConexiones(conexiones);
           
            
            
            
             }
             
               ControladorPrincipal.notificarCambioDatos();
         }
         
         
         
    
}
