/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memento;

import java.util.Date;
import java.util.List;
import modelo.Usuario;

/**
 *
 * @author carlo
 */
public class MementoData {
    List<Usuario> listaUsuarios;
    
    private Date fechaCreacion;
    
    public MementoData(List<Usuario> listaUsuario) {
        
        this.listaUsuarios = listaUsuario;
        
        this.fechaCreacion= new Date();
    }
    
    
    public List<Usuario>  getListaUsuarios() {
        
        
        return  listaUsuarios;
    }
    
    public Date getFechaCreacion() {
        
        return this.fechaCreacion;
    }
    
}
