/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memento;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import modelo.Usuario;

/**
 *
 * @author carlo
 */
public class CareTaker {
    
    private static LinkedList<MementoData>  history = new LinkedList<MementoData>();
    
    private static MementoData presentSnapshot;
    
    public static void inicializaCareTaker(MementoData datos) {
        
        presentSnapshot = datos;
        history.add(datos);
        
        
    }
    
    public static MementoData addSnapShot() {
        
        
        List<Usuario> listaClonada = presentSnapshot.getListaUsuarios().stream().map(u-> u.clone()).collect(Collectors.toList());
        
        MementoData memento = new MementoData(listaClonada) ;
        
        if (!getEsUltimoSnapshot())
            borraHastaFinal();
        
        history.addLast(memento);
        presentSnapshot=memento;
        return memento;
        
        
        
    }
    
    
   
    
    
    public static boolean getEsPrimeroSnapshot() {
        
        return  history.indexOf(presentSnapshot)==0;
        
    }
    
     public static boolean getEsUltimoSnapshot() {
        
       return  history.indexOf(presentSnapshot)== history.indexOf(history.getLast());
        
    }
    
    
    public static MementoData back() {
        
        int index =history.lastIndexOf(presentSnapshot);
        
        if (getEsPrimeroSnapshot()) 
        
               presentSnapshot = history.get(index);
        
        else 
            
            presentSnapshot= history.get(index-1);
        
        
        return presentSnapshot;
    }
    
     
    public static MementoData forward() {
        
        int index =history.indexOf(presentSnapshot);
        
        if (getEsUltimoSnapshot()) 
        
               presentSnapshot = history.get(index);
        
        else 
             presentSnapshot= history.get(index+1);
        
        return presentSnapshot;
    }
    
    
     private static void borraHastaFinal() {
        
        
        IntStream.range(history.indexOf(presentSnapshot)+1,history.lastIndexOf(history.getLast()) ).forEach(index->history.remove(index));
    }
    
    public MementoData getSnapshot() {
        
        return presentSnapshot;
    }
    
}
